# WEARLOOP WEBSITE — SIMPLE EDITING GUIDE

## 1. Open the website
Open `index.html` in a browser to preview it.

## 2. Add an outfit
Open `index.html` in a text editor and find:

const outfits = [

Copy one outfit line and edit:
- id: WL004
- name
- category
- size
- colour
- price
- deposit
- status
- photo
- best

Example:
{id:"WL004",name:"Green Anarkali",category:"Anarkali",size:"L",colour:"Green",price:300,deposit:600,status:"Available",photo:"green.jpg",best:"Festive"}

## 3. Remove an outfit
Delete its entire `{ ... }` line from the outfits list.

## 4. Change an outfit
Edit the values inside that outfit's `{ ... }`.

## 5. Add photos
The easiest reliable setup is to keep your images in the same folder as index.html.
For example:
- index.html
- pink-lehenga.jpg
- blue-saree.jpg

Then use:
photo:"pink-lehenga.jpg"

If you later host the site on GitHub Pages, this works well.

## 6. Change coordinator numbers
Find the Contact Your Coordinators section in index.html and replace the blank lines with your names/numbers.

## 7. Add your Google Form
Create a Google Form for "List Your Outfit", copy its link, and replace the `href="#"` in the List Your Outfit button with that link.

## 8. Publish it free
A simple option is GitHub Pages:
1. Create a GitHub account.
2. Create a new repository (for example `wearloop-catalogue`).
3. Upload `index.html` and your photo files.
4. In repository Settings → Pages, choose the main branch and root folder.
5. GitHub will give you a public website URL.
6. Put that URL into your poster's QR code.

Every time you edit `index.html` or replace/add photos and upload the changes, the public website updates.

IMPORTANT:
- Do not put private owner/renter phone numbers in the public website.
- Keep your master rental records in the Excel/Google Sheet.
- Use Outfit IDs (WL001, WL002...) when students enquire.


UPDATED LISTING SYSTEM
Students do not submit outfits directly. They must text a Wearloop coordinator first. The Wearloop team verifies the outfit and then adds it to the catalogue manually.
